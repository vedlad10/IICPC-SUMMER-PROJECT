// ============================================================
// TrustEngine NDE v5.7 — content.js
// NEW: Image right-click scanning + conversation context sent with text verify
// ============================================================

const BACKEND_BASE = "http://127.0.0.1:8000";
let hoverScanEnabled = false;
let isAutoScrolling  = false;
let panelOpen        = false;

// ── 1. IDENTITY DETECTION ────────────────────────────────────
function getChatContext() {
    const host = window.location.hostname;
    if (host.includes("instagram.com")) {
        const urlParts = window.location.pathname.split('/');
        const chatID   = urlParts.includes('t') ? urlParts[urlParts.indexOf('t') + 1] : null;
        const profileLink = document.querySelector('a[aria-label^="Open the profile page of"]');
        let username = "IG_User";
        if (profileLink) username = profileLink.getAttribute('aria-label').replace('Open the profile page of ', '').trim();
        return { platform: "instagram", chatID, username };
    }
    if (host.includes("mail.google.com")) {
        const emailEl = document.querySelector('span.gD');
        const email   = emailEl ? emailEl.getAttribute('email') : null;
        return { platform: "gmail", chatID: email, username: email || "Gmail_User" };
    }
    return { platform: "unknown", chatID: null, username: "Unknown" };
}

// ── 2. SCRAPER ───────────────────────────────────────────────
function scrapeInstagram() {
    const messages   = [];
    const seen       = new Set();
    const messageNodes = document.querySelectorAll('div[dir="auto"], span.xexx8yu');
    const chatArea   = document.querySelector('section main') || document.body;
    const chatRect   = chatArea.getBoundingClientRect();
    const chatCenter = chatRect.left + (chatRect.width / 2);

    messageNodes.forEach(node => {
        if (node.tagName === 'SPAN' && node.closest('div[dir="auto"]')) return;
        if (node.tagName === 'DIV'  && node.querySelector('div[dir="auto"]')) return;
        if (node.closest('h1, h2, h3, h4, h5, header')) return;
        const nodeRect = node.getBoundingClientRect();
        if (nodeRect.left > chatCenter) return;

        let text;
        const imgs = node.querySelectorAll('img');
        if (imgs.length > 0) {
            const clone = node.cloneNode(true);
            clone.querySelectorAll('img').forEach(img => {
                const alt = img.getAttribute('alt');
                if (alt) img.replaceWith(document.createTextNode(alt));
            });
            text = clone.innerText.trim();
        } else {
            text = node.innerText.trim();
        }

        if (!text || text.length === 0) return;
        if (text === "·" || text === "1") return;
        if (/^\d+[smhdwys]$/i.test(text)) return;
        if (/^\d{1,2}:\d{2}\s*(AM|PM)?$/i.test(text)) return;
        if (/^(Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s\d{1,2}:\d{2}/i.test(text)) return;

        const lowerText = text.toLowerCase();
        if (lowerText.includes("profile picture")) return;
        const uiGarbage = [
            "message...", "messages", "requests", "active ", "active today",
            "new thought", "reacted", "removed", "sent an attachment",
            "story unavailable", "replied to you", "replied to",
            "seen", "delivered", "sending", "tap to retry", "instagram",
            "started a video call", "started an audio call", "missed video call"
        ];
        if (uiGarbage.some(g => lowerText.includes(g))) return;
        if (seen.has(text)) return;
        seen.add(text);
        messages.push(text);
    });

    console.log(`🛡️ Extracted ${messages.length} clean incoming messages.`);
    return messages;
}

function scrapeGmail() {
    return Array.from(document.querySelectorAll('div.a3s')).map(el => el.innerText.trim());
}

// ── 3. CONVERSATION CONTEXT COLLECTOR ───────────────────────
// Grabs last 5 visible incoming messages (other than the one being scanned)
// These are sent to /verify/text so the backend can weight them by recency
function getConversationContext(excludeNode) {
    const allNodes = Array.from(document.querySelectorAll('div[dir="auto"]'));
    const chatArea = document.querySelector('section main') || document.body;
    const chatRect = chatArea.getBoundingClientRect();
    const chatCenter = chatRect.left + (chatRect.width / 2);

    const context = [];
    for (const node of allNodes) {
        if (node === excludeNode) continue;
        const rect = node.getBoundingClientRect();
        if (rect.left > chatCenter) continue; // skip own messages
        const text = node.innerText.trim();
        if (text && text.length > 3) context.push(text);
        if (context.length >= 5) break;
    }
    return context;
}

// ── 4. AUTO-SCROLL ───────────────────────────────────────────
async function startAutoScroll() {
    isAutoScrolling = true;
    showScrollOverlay();
    while (isAutoScrolling) {
        const scrollables = document.querySelectorAll('div[style*="overflow-y: auto"], div[style*="overflow: hidden auto"]');
        scrollables.forEach(el => { el.scrollTop = 0; el.scrollBy(0, -5000); });
        const msgs = document.querySelectorAll('div[dir="auto"]');
        if (msgs.length > 0) {
            try { msgs[0].scrollIntoView({ behavior: 'smooth', block: 'end' }); } catch(e){}
        }
        const chatArea = document.querySelector('section main') || document.body;
        chatArea.dispatchEvent(new WheelEvent('wheel', {
            bubbles: true, cancelable: true, deltaY: -5000,
            clientX: window.innerWidth / 2, clientY: window.innerHeight / 2
        }));
        chatArea.dispatchEvent(new KeyboardEvent('keydown', {
            bubbles: true, cancelable: true, key: 'PageUp', keyCode: 33
        }));
        await new Promise(r => setTimeout(r, 1500));
    }
}

// ── 5. DRAGGABLE UI ──────────────────────────────────────────
function injectDraggableUI() {
    if (document.getElementById('te-app-container')) return;
    const container = document.createElement('div');
    container.id    = 'te-app-container';
    container.innerHTML = `
        <div id="te-fab">🛡️</div>
        <div id="te-panel">
            <div class="te-header">
                <div class="te-brand">TrustEngine</div>
                <div id="te-target-user">Scanning...</div>
            </div>
            <div class="te-body">
                <button id="te-feed-btn" class="te-btn te-btn-primary">📥 Ingest Profile</button>
                <button id="te-vault-btn" class="te-btn te-btn-secondary">📁 Registry Vault</button>
                <div class="te-toggle-box">
                    <span>Auto-Scan</span>
                    <label class="te-switch"><input type="checkbox" id="te-hover-chk"><span class="te-slider"></span></label>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(container);

    document.getElementById('te-feed-btn').onclick  = startAutoScroll;
    document.getElementById('te-vault-btn').onclick = showVault;
    document.getElementById('te-hover-chk').onchange = (e) => hoverScanEnabled = e.target.checked;

    const fab   = document.getElementById('te-fab');
    const panel = document.getElementById('te-panel');
    let isDragging = false, startX, startY, initialX, initialY;

    fab.onmousedown = (e) => {
        isDragging = false;
        startX = e.clientX; startY = e.clientY;
        const rect = container.getBoundingClientRect();
        initialX = rect.left; initialY = rect.top;
        document.onmousemove = (mv) => {
            let dx = mv.clientX - startX, dy = mv.clientY - startY;
            if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
                isDragging = true;
                container.style.left   = `${initialX + dx}px`;
                container.style.top    = `${initialY + dy}px`;
                container.style.bottom = 'auto';
                container.style.right  = 'auto';
            }
        };
        document.onmouseup = () => { document.onmousemove = null; document.onmouseup = null; };
    };
    fab.onclick = (e) => {
        if (isDragging) return;
        panelOpen = !panelOpen;
        panel.classList.toggle('te-open', panelOpen);
    };

    setInterval(() => {
        const { username } = getChatContext();
        document.getElementById('te-target-user').innerText = username || "Standby";
    }, 1500);
}

// ── 6. OVERLAYS ──────────────────────────────────────────────
function showScrollOverlay() {
    const overlay = document.createElement('div');
    overlay.id    = 'te-scroll-overlay';
    overlay.innerHTML = `
        <div class="te-scroll-card">
            <div class="te-loader-ring"></div>
            <h3>Ingesting Data...</h3>
            <button id="te-stop-btn">Stop & Capture</button>
        </div>
    `;
    document.body.appendChild(overlay);
    document.getElementById('te-stop-btn').onclick = () => {
        isAutoScrolling = false;
        overlay.remove();
        handleCapture();
    };
}

async function handleCapture() {
    const ctx      = getChatContext();
    const messages = ctx.platform === "instagram" ? scrapeInstagram() : scrapeGmail();
    const customName = window.prompt("Confirm Vault Identity:", ctx.username);
    if (customName) {
        await fetch(`${BACKEND_BASE}/enroll/contact`, {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ chatID: ctx.chatID, name: customName, messages, platform: ctx.platform })
        });
        alert(`✅ Trust Profile for ${customName} Synced!`);
    }
}

async function showVault() {
    try {
        const res = await fetch(`${BACKEND_BASE}/contacts`);
        const db  = await res.json();
        const overlay = document.createElement('div');
        overlay.className = 'te-modal-overlay';

        const rows = Object.entries(db).map(([id, data]) => `
            <div class="te-row">
                <div class="te-row-info">
                    <div class="te-row-name">${data.name} <span class="te-badge">${data.platform}</span></div>
                    <div class="te-row-meta">${data.history ? data.history.length : 0} messages · threshold ${data.threshold || 45}%</div>
                </div>
                <button class="te-btn-del delete-profile-btn" data-id="${id}">🗑️</button>
            </div>
        `).join('');

        overlay.innerHTML = `
            <div class="te-modal-content">
                <div class="te-modal-header">
                    <h3>📁 Registry Vault</h3>
                    <button id="te-close-modal">✕</button>
                </div>
                <div class="te-grid">
                    ${rows || '<div style="text-align:center;color:#94a3b8;padding:20px;">Vault is empty.</div>'}
                </div>
            </div>
        `;
        document.body.appendChild(overlay);
        document.getElementById('te-close-modal').onclick = () => overlay.remove();

        overlay.querySelectorAll('.delete-profile-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const b  = e.target.closest('button');
                const id = b.getAttribute('data-id');
                if (confirm("Delete this profile?")) {
                    await fetch(`${BACKEND_BASE}/contact/${id}`, { method: 'DELETE' });
                    b.closest('.te-row').remove();
                }
            });
        });
    } catch (e) {
        alert("Backend offline. Cannot open vault.");
    }
}

// ── 7. BADGE BUILDER ─────────────────────────────────────────
function scoreColor(score) {
    if (score >= 70) return '#22c55e';
    if (score >= 45) return '#f59e0b';
    return '#ef4444';
}
function scoreLabel(score) {
    if (score >= 70) return 'Authentic';
    if (score >= 45) return 'Uncertain';
    return 'Imposter';
}

function buildResultBadge(badgeEl, data) {
    const final     = Math.round(data.final_score    ?? data.confidence ?? 0);
    const semantic  = Math.round(data.semantic_score ?? 0);
    const style     = Math.round(data.style_score    ?? 0);
    const threshold = Math.round(data.threshold      ?? 45);
    const ctxUsed   = data.context_used              ?? 0;

    const color         = scoreColor(final);
    const label         = scoreLabel(final);
    const r             = 28;
    const circumference = 2 * Math.PI * r;
    const filled        = (final / 100) * circumference;

    // For image results, show detail breakdown if available
    const detailRows = (data.details || []).map(d =>
        `<div class="te-bar-row">
            <span class="te-bar-label">${d.name}</span>
            <div class="te-bar-track">
                <div class="te-bar-fill" style="width:0%;background:${scoreColor(d.score)};" data-target="${Math.round(d.score)}"></div>
            </div>
            <span class="te-bar-val" style="color:${scoreColor(d.score)};">${Math.round(d.score)}%</span>
        </div>`
    ).join('');

    // Use detail rows for images, style/semantic for text
    const barsHTML = data.details
        ? detailRows
        : `<div class="te-bar-row">
               <span class="te-bar-label">Style</span>
               <div class="te-bar-track">
                   <div class="te-bar-fill" style="width:0%;background:${scoreColor(style)};" data-target="${style}"></div>
               </div>
               <span class="te-bar-val" style="color:${scoreColor(style)};">${style}%</span>
           </div>
           <div class="te-bar-row">
               <span class="te-bar-label">Topic</span>
               <div class="te-bar-track">
                   <div class="te-bar-fill" style="width:0%;background:${scoreColor(semantic)};" data-target="${semantic}"></div>
               </div>
               <span class="te-bar-val" style="color:${scoreColor(semantic)};">${semantic}%</span>
           </div>
           <div class="te-threshold-row">
               <span class="te-bar-label" style="color:#64748b;">Threshold</span>
               <span class="te-bar-val" style="color:#64748b;">${threshold}%</span>
           </div>`;

    const ctxNote = ctxUsed > 0
        ? `<div class="te-ctx-note">+ ${ctxUsed} context msgs</div>`
        : '';

    badgeEl.innerHTML = `
        <div class="te-result-grid">
            <div class="te-ring-wrap">
                <svg width="72" height="72" viewBox="0 0 72 72">
                    <circle cx="36" cy="36" r="${r}" fill="none" stroke="rgba(255,255,255,0.08)" stroke-width="6"/>
                    <circle cx="36" cy="36" r="${r}" fill="none" stroke="${color}" stroke-width="6"
                        stroke-linecap="round"
                        stroke-dasharray="0 ${circumference}"
                        stroke-dashoffset="${circumference / 4}"
                        class="te-ring-arc"
                        style="transition: stroke-dasharray 0.8s cubic-bezier(.4,0,.2,1);"
                        data-filled="${filled}" data-circ="${circumference}"/>
                    <text x="36" y="39" text-anchor="middle"
                        font-size="13" font-weight="700" fill="${color}"
                        font-family="Inter, system-ui, sans-serif">${final}%</text>
                </svg>
                <div class="te-ring-label" style="color:${color};">${label}</div>
                ${ctxNote}
            </div>
            <div class="te-bars-wrap">${barsHTML}</div>
        </div>
    `;

    requestAnimationFrame(() => {
        const arc = badgeEl.querySelector('.te-ring-arc');
        if (arc) arc.style.strokeDasharray = `${filled} ${circumference - filled}`;
        badgeEl.querySelectorAll('.te-bar-fill').forEach(bar => {
            const target = bar.getAttribute('data-target');
            setTimeout(() => { bar.style.width = `${target}%`; }, 100);
        });
    });
}

function buildLoadingBadge() {
    const badge = document.createElement('div');
    badge.className = 'te-inline-badge te-loading';
    badge.innerHTML = `
        <div class="te-loading-row">
            <div class="te-loader-ring-sm"></div>
            <span class="te-loading-text">Scanning identity...</span>
        </div>
    `;
    return badge;
}

// ── 8. IMAGE → BLOB → BACKEND ────────────────────────────────
async function fetchImageAsBlob(imgEl) {
    // Try natural src first, fall back to canvas for cross-origin
    try {
        const res = await fetch(imgEl.src, { mode: 'cors' });
        if (res.ok) return await res.blob();
    } catch (_) {}

    // Canvas fallback
    const canvas = document.createElement('canvas');
    canvas.width  = imgEl.naturalWidth  || imgEl.width  || 200;
    canvas.height = imgEl.naturalHeight || imgEl.height || 200;
    canvas.getContext('2d').drawImage(imgEl, 0, 0);
    return await new Promise(res => canvas.toBlob(res, 'image/jpeg', 0.92));
}

async function scanImage(imgEl, wrapper) {
    const existing = wrapper.querySelector('.te-inline-badge');
    if (existing) existing.remove();

    imgEl.style.outline = '2px solid #3b82f6';
    const badge = buildLoadingBadge();
    badge.id    = 'te-img-badge-' + Date.now();
    wrapper.appendChild(badge);

    try {
        const blob    = await fetchImageAsBlob(imgEl);
        const form    = new FormData();
        form.append('file', blob, 'scan.jpg');
        form.append('photo_type', 'auto');

        const res  = await fetch(`${BACKEND_BASE}/verify/image`, { method: 'POST', body: form });
        const data = await res.json();

        imgEl.style.outline = '';
        const b = document.getElementById(badge.id);
        if (b) {
            b.className = 'te-inline-badge te-result';
            buildResultBadge(b, data);

            // If heatmap is returned, append it below the badge
            if (data.heatmap) {
                const hm  = document.createElement('img');
                hm.src    = data.heatmap;
                hm.title  = 'ELA Heatmap';
                hm.className = 'te-heatmap';
                b.appendChild(hm);
            }
        }
    } catch (e) {
        imgEl.style.outline = '';
        const b = document.getElementById(badge.id);
        if (b) {
            b.className = 'te-inline-badge te-error';
            b.innerHTML = `<span style="color:#ef4444;font-size:13px;">❌ Backend offline</span>`;
        }
    }
}

// ── 9. RIGHT-CLICK TRACKING ──────────────────────────────────
let lastRightClickedText  = null;
let lastRightClickedImage = null;

document.addEventListener('contextmenu', (e) => {
    lastRightClickedText  = e.target.closest('div[dir="auto"], .xexx8yu, span.xexx8yu');
    // Track images separately — Instagram sends images inside <img> tags
    const imgEl = e.target.closest('img');
    lastRightClickedImage = (imgEl && imgEl.src && !imgEl.src.startsWith('data:')) ? imgEl : null;
}, true);

// ── 10. MESSAGE LISTENER ─────────────────────────────────────
chrome.runtime.onMessage.addListener(async (msg) => {
    const ctx = getChatContext();

    // ── TEXT VERIFY ────────────────────────────────────────────
    if (msg.action === "VERIFY_HIGHLIGHTED_TEXT") {
        const targetNode = lastRightClickedText;
        if (!targetNode) {
            console.log("TrustEngine: No message bubble under cursor.");
            return;
        }

        const textToVerify    = targetNode.innerText.trim();
        const contextMessages = getConversationContext(targetNode);
        const wrapper         = targetNode.closest('.x14ctfv') || targetNode.parentElement;

        targetNode.classList.add('te-scanning-glass');

        const existing = wrapper.querySelector('.te-inline-badge');
        if (existing) existing.remove();

        const badge = buildLoadingBadge();
        badge.id    = 'te-verdict-' + Date.now();
        wrapper.appendChild(badge);

        try {
            const res = await fetch(`${BACKEND_BASE}/verify/text`, {
                method: "POST", headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    text:    textToVerify,
                    chatID:  ctx.chatID,
                    context: contextMessages   // ← conversation context sent here
                })
            });
            const data = await res.json();

            targetNode.classList.remove('te-scanning-glass');
            const b = document.getElementById(badge.id);
            if (b) {
                b.className = 'te-inline-badge te-result';
                buildResultBadge(b, data);
            }
        } catch (e) {
            targetNode.classList.remove('te-scanning-glass');
            const b = document.getElementById(badge.id);
            if (b) {
                b.className = 'te-inline-badge te-error';
                b.innerHTML = `<span style="color:#ef4444;font-size:13px;">❌ Backend offline</span>`;
            }
        }
    }

    // ── IMAGE VERIFY ───────────────────────────────────────────
    if (msg.action === "VERIFY_IMAGE") {
        const imgEl = lastRightClickedImage;
        if (!imgEl) {
            console.log("TrustEngine: No image under cursor.");
            return;
        }
        const wrapper = imgEl.parentElement;
        await scanImage(imgEl, wrapper);
    }
});

if (document.readyState === 'complete') injectDraggableUI();
else window.addEventListener('load', injectDraggableUI);