# DeepGuard Chrome Extension

Deepfake Trust Engine — Chrome Extension component.

## Files

| File | Purpose |
|---|---|
| `manifest.json` | Extension config, permissions, host patterns |
| `background.js` | Service worker — context menus + click routing |
| `content.js` | DOM scraper, toast UI, badge injection (Gmail & Instagram) |
| `content.css` | Styles for injected toast & verdict badge |
| `popup.html` | Extension popup markup |
| `popup.js` | Popup logic — platform display, last result, health check |

## Setup

### 1. Add backend URL
In **both** `background.js` and `popup.js`, replace:
```
const BACKEND_BASE = "https://your-hf-space.hf.space";
```
with your actual Hugging Face Space URL.

### 2. Add icons
Create an `icons/` folder with:
- `icon16.png` (16×16)
- `icon48.png` (48×48)  
- `icon128.png` (128×128)

You can generate these from any shield/lock icon at https://favicon.io

### 3. Load in Chrome
1. Go to `chrome://extensions`
2. Enable **Developer mode** (top right)
3. Click **Load unpacked**
4. Select this folder

## Usage

### Feed chat (build contact profile)
1. Open a Gmail thread or Instagram DM
2. Right-click the page (not on an element)
3. Click **"🧠 Feed this chat (build profile)"**
4. A toast confirms how many messages were sent to `/enroll/contact`

### Check selected text for deepfake
1. On Gmail or Instagram, **select any text**
2. Right-click the selection
3. Click **"🔍 Check this message for deepfake"**
4. A verdict badge appears near the selection (🔴 FAKE / 🟡 SUSPICIOUS / 🟢 REAL)

## Backend Endpoints Used

| Endpoint | Triggered by |
|---|---|
| `POST /enroll/contact` | "Feed this chat" context menu |
| `POST /verify/text` | "Check this message" context menu |
| `GET /health` | Popup health check on open |

## Payload Shapes

### /enroll/contact
```json
{
  "platform": "gmail",
  "messages": [
    { "sender": "alice@example.com", "subject": "Meeting", "text": "...", "timestamp": "10:30 AM" }
  ]
}
```

### /verify/text
```json
{ "text": "Selected message text here..." }
```
Expected response:
```json
{ "verdict": "FAKE", "confidence": 0.87 }
```
