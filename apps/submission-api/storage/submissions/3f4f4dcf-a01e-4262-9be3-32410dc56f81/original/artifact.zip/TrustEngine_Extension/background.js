// background.js | TrustEngine NDE v5.7

chrome.runtime.onInstalled.addListener(() => {
    // Text message scan
    chrome.contextMenus.create({
        id:       "VERIFY_TEXT",
        title:    "🛡️ TrustEngine: Scan this message",
        contexts: ["all"]
    });

    // Image scan
    chrome.contextMenus.create({
        id:       "VERIFY_IMAGE",
        title:    "🔍 TrustEngine: Scan this image",
        contexts: ["image", "all"]
    });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "VERIFY_TEXT") {
        chrome.tabs.sendMessage(tab.id, { action: "VERIFY_HIGHLIGHTED_TEXT" });
    }
    if (info.menuItemId === "VERIFY_IMAGE") {
        chrome.tabs.sendMessage(tab.id, { action: "VERIFY_IMAGE" });
    }
});