const BACKEND_BASE = "http://127.0.0.1:8000";

// ── 1. INITIALIZE ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    checkBackend();
    updatePlatform();
    loadLastResult();
});

// ── 2. HEALTH CHECK ───────────────────────────────────────────
async function checkBackend() {
    const dot = document.getElementById('status-dot');
    const text = document.getElementById('status-text');
    
    try {
        const res = await fetch(`${BACKEND_BASE}/`);
        if (res.ok) {
            dot.style.background = "#10b981"; // Green
            text.innerText = "Online";
        }
    } catch (e) {
        dot.style.background = "#ef4444"; // Red
        text.innerText = "Offline";
    }
}

// ── 3. PLATFORM DETECTION ─────────────────────────────────────
async function updatePlatform() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const tag = document.getElementById('platform-tag');
    
    if (tab.url.includes("instagram.com")) {
        tag.innerText = "Instagram";
        tag.style.color = "#f472b6"; // Pink
    } else if (tab.url.includes("mail.google.com")) {
        tag.innerText = "Gmail";
        tag.style.color = "#fbbf24"; // Amber
    } else {
        tag.innerText = "Unknown Site";
    }
}

// ── 4. LOAD RECENT DATA ───────────────────────────────────────
function loadLastResult() {
    chrome.storage.local.get(['lastResult'], (data) => {
        const display = document.getElementById('result-display');
        if (data.lastResult) {
            display.innerText = data.lastResult.verdict || "Scan complete.";
            display.style.borderColor = data.lastResult.badge_color || "#3b82f6";
        }
    });
}

// ── 5. BUTTON HANDLERS ────────────────────────────────────────
document.getElementById('btn-dashboard').onclick = () => {
    chrome.tabs.create({ url: `${BACKEND_BASE}/view-contacts` });
};

document.getElementById('btn-clear').onclick = () => {
    chrome.storage.local.clear(() => {
        location.reload();
    });
};