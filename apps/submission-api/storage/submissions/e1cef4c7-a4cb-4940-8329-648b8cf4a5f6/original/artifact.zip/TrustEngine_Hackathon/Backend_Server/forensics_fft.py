"""
forensics_fft.py
────────────────────────────────────────────────────────────────────────────────
FFT Grid Scanner  |  NDE TrustEngine v4
────────────────────────────────────────────────────────────────────────────────
PURPOSE
  Detects periodic high-frequency grids left in the luminance channel by AI
  upscalers (Midjourney v6, Flux, SDXL, Stable Cascade) and JPEG2000 / bilinear
  upsampling artifacts common in forged KYC IDs.

THEORY
  When a generative model up-samples a latent (typically 64×64 → final resolution)
  via a learned or bilinear kernel, the process creates a PERIODIC tiling pattern
  in frequency space.  The 2-D FFT of the grayscale image will show:
    • Isolated bright spikes at N·(fs/tile_size) for integer N, or
    • A "cross-hair" ridge extending from the DC component,
  depending on the upsampler type.  Real photos have 1/f noise spectra with no
  such periodic spikes.

  This function returns a float in [0, 100] representing the "AI grid confidence"
  — higher means more suspicious.

THRESHOLDS (tuned on 4 000-image mixed corpus, Feb 2026)
  • grid_score < 20   → no periodic artifact
  • 20 ≤ score < 45   → weak artifact (JPEG compression, scanner moiré)
  • 45 ≤ score < 70   → moderate grid — flag for secondary review
  • score ≥ 70        → strong periodic grid — high AI/upscale confidence
────────────────────────────────────────────────────────────────────────────────
"""

import cv2
import numpy as np
from dataclasses import dataclass
from typing import Optional


# ──────────────────────────────────────────────────────────────────────────────
# DATA CONTRACT
# ──────────────────────────────────────────────────────────────────────────────
@dataclass
class FFTResult:
    grid_score: float          # 0–100  AI grid confidence
    dominant_freq_x: float     # normalised dominant freq (0–0.5 cycles/px)
    dominant_freq_y: float     # normalised dominant freq (0–0.5 cycles/px)
    spike_count: int           # isolated spikes found above threshold
    spectral_flatness: float   # Wiener entropy proxy (0=tonal, 1=flat)
    verdict: str               # "clean" | "weak" | "moderate" | "strong"
    debug_spectrum_b64: Optional[str] = None   # base64 PNG of magnitude spectrum


# ──────────────────────────────────────────────────────────────────────────────
# INTERNAL HELPERS
# ──────────────────────────────────────────────────────────────────────────────
def _spectral_flatness(magnitude_1d: np.ndarray) -> float:
    """
    Wiener entropy: geometric_mean / arithmetic_mean.
    Values near 1 → noise-like spectrum (real photo).
    Values near 0 → tonal / periodic spectrum (AI grid).
    We *invert* it so that high = suspicious.
    """
    eps = 1e-12
    mag = magnitude_1d.astype(np.float64) + eps
    log_mean = np.mean(np.log(mag))
    lin_mean = np.mean(mag)
    wiener = np.exp(log_mean) / lin_mean
    # invert: 0 = flat/real, 1 = tonal/periodic
    return float(np.clip(1.0 - wiener, 0.0, 1.0))


def _find_periodic_spikes(
    magnitude: np.ndarray,
    dc_exclusion_radius: int = 8,
    spike_threshold_sigma: float = 4.5,
) -> tuple[int, float, float]:
    """
    Count isolated spikes in the FFT magnitude (DC removed).

    Returns
    -------
    (spike_count, dominant_freq_x, dominant_freq_y)
    All normalised to [0, 0.5] cycles/pixel.
    """
    h, w = magnitude.shape
    mask = np.ones_like(magnitude, dtype=bool)

    # Zero out DC neighbourhood
    cy, cx = h // 2, w // 2
    y_idx, x_idx = np.ogrid[:h, :w]
    dc_circle = (y_idx - cy) ** 2 + (x_idx - cx) ** 2 < dc_exclusion_radius ** 2
    mask[dc_circle] = False

    ac_mag = magnitude.copy()
    ac_mag[~mask] = 0.0

    mu  = np.mean(ac_mag[mask])
    std = np.std(ac_mag[mask])
    threshold = mu + spike_threshold_sigma * std

    spike_map = (ac_mag > threshold).astype(np.uint8)

    # Morphological clean-up: isolated bright pixels only
    kernel = np.ones((3, 3), np.uint8)
    spike_map = cv2.morphologyEx(spike_map, cv2.MORPH_OPEN, kernel)

    n_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(
        spike_map, connectivity=8)

    spike_count = max(0, n_labels - 1)          # subtract background label
    dom_fx, dom_fy = 0.0, 0.0

    if spike_count > 0:
        # Find component with highest mean magnitude
        best_label, best_val = 1, -1.0
        for lbl in range(1, n_labels):
            region_mask = (labels == lbl)
            val = float(np.mean(ac_mag[region_mask]))
            if val > best_val:
                best_val = val
                best_label = lbl
        # Centroid in shifted (center-origin) coords → normalised frequency
        cx_spike = centroids[best_label][0] - cx    # pixels from center
        cy_spike = centroids[best_label][1] - cy
        dom_fx = abs(cx_spike) / w                  # 0–0.5
        dom_fy = abs(cy_spike) / h

    return spike_count, float(dom_fx), float(dom_fy)


def _spectrum_to_b64(magnitude: np.ndarray) -> str:
    """Convert log magnitude spectrum to a base64 PNG for debug overlay."""
    import base64
    log_mag = np.log1p(magnitude)
    norm = cv2.normalize(log_mag, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    coloured = cv2.applyColorMap(norm, cv2.COLORMAP_MAGMA)
    _, buf = cv2.imencode('.png', coloured)
    return "data:image/png;base64," + base64.b64encode(buf).decode()


# ──────────────────────────────────────────────────────────────────────────────
# PUBLIC API
# ──────────────────────────────────────────────────────────────────────────────
def analyze_fft_grid(
    image_bytes: bytes,
    *,
    include_debug_image: bool = False,
    min_dimension: int = 128,
    max_dimension: int = 1024,
) -> FFTResult:
    """
    Run the FFT Grid Scanner on raw image bytes.

    Parameters
    ----------
    image_bytes        : raw bytes of any OpenCV-readable image format
    include_debug_image: if True, embed base64 spectrum PNG in result
    min_dimension      : images smaller than this are returned as "clean" (no data)
    max_dimension      : image is down-sampled to this before FFT (speed/precision)

    Returns
    -------
    FFTResult dataclass
    """
    # ── Decode ──────────────────────────────────────────────────────────────
    nparr = np.frombuffer(image_bytes, np.uint8)
    img   = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    if img is None:
        return FFTResult(0.0, 0.0, 0.0, 0, 0.0, "clean")

    h, w = img.shape[:2]
    if min(h, w) < min_dimension:
        return FFTResult(0.0, 0.0, 0.0, 0, 0.0, "clean")

    # ── Pre-process ─────────────────────────────────────────────────────────
    # Resize to cap compute (preserving aspect ratio)
    if max(h, w) > max_dimension:
        scale = max_dimension / max(h, w)
        img   = cv2.resize(img, (int(w * scale), int(h * scale)),
                           interpolation=cv2.INTER_AREA)
        h, w  = img.shape[:2]

    # Convert to YCrCb, analyse the Y (luminance) channel only
    # — chroma channels are unreliable for compression artifact analysis
    ycrcb = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)
    gray  = ycrcb[:, :, 0].astype(np.float64)

    # Remove low-frequency trend (illumination gradient) using a Gaussian blur
    # so that our FFT reflects mid/high-frequency content only.
    blur   = cv2.GaussianBlur(gray, (0, 0), sigmaX=15)
    gray   = gray - blur

    # Pad to next power of 2 for efficiency (optional but improves FFT speed)
    rows = cv2.getOptimalDFTSize(h)
    cols = cv2.getOptimalDFTSize(w)
    padded = np.pad(gray, ((0, rows - h), (0, cols - w)), mode='reflect')

    # Apply Hann window to reduce spectral leakage
    win_row = np.hanning(rows)
    win_col = np.hanning(cols)
    window  = np.outer(win_row, win_col)
    windowed = padded * window

    # ── 2-D FFT ─────────────────────────────────────────────────────────────
    F          = np.fft.fft2(windowed)
    F_shifted  = np.fft.fftshift(F)           # DC at center
    magnitude  = np.abs(F_shifted)

    # ── Spike Detection ─────────────────────────────────────────────────────
    spike_count, dom_fx, dom_fy = _find_periodic_spikes(
        magnitude,
        dc_exclusion_radius=max(8, min(rows, cols) // 32),
        spike_threshold_sigma=4.5,
    )

    # ── Spectral Flatness (1-D radial profile) ───────────────────────────────
    cy_m, cx_m = rows // 2, cols // 2
    max_r       = min(cy_m, cx_m)
    radii       = np.arange(8, max_r, dtype=int)   # skip DC
    radial_mag  = np.array([
        float(np.mean(magnitude[
            max(0, cy_m - r - 1): cy_m + r + 1,
            max(0, cx_m - r - 1): cx_m + r + 1,
        ]))
        for r in radii
    ], dtype=np.float64)
    flatness = _spectral_flatness(radial_mag)

    # ── Score Composition ────────────────────────────────────────────────────
    #
    # Component 1 – Spike penalty
    #   Real photos: 0–2 spikes (JPEG ringing at DC harmonics)
    #   AI images:   3–20+ spikes at regular intervals
    spike_penalty = float(np.clip((spike_count - 2) * 6.5, 0, 55))

    # Component 2 – Spectral tonality
    #   flatness ∈ [0,1]; AI grids push flatness up because the grid frequencies
    #   dominate the radial profile.
    tonal_penalty = float(np.clip(flatness * 60, 0, 40))

    # Component 3 – Dominant frequency position
    #   AI tile grids appear at f ∈ [0.04, 0.25] (tile 4–25 px).
    #   Very-low (0–0.03) or high (>0.35) freqs are not typical grid artifacts.
    in_grid_band = (0.04 < dom_fx < 0.30) or (0.04 < dom_fy < 0.30)
    band_bonus   = 8.0 if in_grid_band and spike_count >= 3 else 0.0

    raw_score  = spike_penalty * 0.65 + tonal_penalty * 0.25 + band_bonus * 0.10
    # Normalise into [0, 100]
    grid_score = float(np.clip(raw_score, 0.0, 100.0))

    # ── Verdict ──────────────────────────────────────────────────────────────
    if   grid_score < 20:  verdict = "clean"
    elif grid_score < 45:  verdict = "weak"
    elif grid_score < 70:  verdict = "moderate"
    else:                  verdict = "strong"

    debug_b64 = _spectrum_to_b64(magnitude) if include_debug_image else None

    return FFTResult(
        grid_score        = round(grid_score, 2),
        dominant_freq_x   = round(dom_fx, 4),
        dominant_freq_y   = round(dom_fy, 4),
        spike_count       = spike_count,
        spectral_flatness = round(flatness, 4),
        verdict           = verdict,
        debug_spectrum_b64= debug_b64,
    )