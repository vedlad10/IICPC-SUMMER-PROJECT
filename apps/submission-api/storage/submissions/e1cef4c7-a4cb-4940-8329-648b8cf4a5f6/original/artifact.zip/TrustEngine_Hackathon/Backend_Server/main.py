"""
main.py | TrustEngine NDE v4.7
────────────────────────────────────────────────────────────────────────────────
NEW IN v4.7:
  - HTML dashboard at / (no more raw JSON)
  - DELETE /contact/{id} endpoint (vault delete now works)
  - Conversation context scoring: weights last N messages by recency
  - Image verify wired through consensus engine
────────────────────────────────────────────────────────────────────────────────
"""

import cv2
import numpy as np
import re
import base64
import json
import os
from datetime import datetime

import torch
from fastapi import FastAPI, File, UploadFile, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from sentence_transformers import SentenceTransformer, util

# ── 1. LOAD MODEL ─────────────────────────────────────────────
sentence_model = SentenceTransformer('all-MiniLM-L6-v2')

# ── 2. APP SETUP ──────────────────────────────────────────────
app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DB_FILE = "trust_profiles.json"

try:
    from forensics_fft import analyze_fft_grid
    from forensics_liveness import analyze_liveness
    from consensus_engine import resolve_consensus, ConsensusResult
except ImportError as e:
    print(f"⚠️  Forensic modules not found: {e}")

# ── 3. DATABASE ───────────────────────────────────────────────
def get_db():
    if not os.path.exists(DB_FILE):
        return {}
    with open(DB_FILE, "r") as f:
        try:
            return json.load(f)
        except:
            return {}

def save_db(db):
    with open(DB_FILE, "w") as f:
        json.dump(db, f, indent=4)

# ── 4. STYLOMETRIC HELPERS ────────────────────────────────────
def get_stylometric_features(text: str) -> dict:
    sentences = re.split(r'[.!?]+', text)
    words     = text.lower().split()
    return {
        "avg_word_len":   sum(len(w) for w in words) / max(len(words), 1),
        "vocab_richness": len(set(words)) / max(len(words), 1),
        "punct_density":  len(re.findall(r'[!?.,;:]', text)) / max(len(text), 1),
        "caps_ratio":     sum(1 for c in text if c.isupper()) / max(len(text), 1),
        "avg_sent_len":   sum(len(s.split()) for s in sentences) / max(len(sentences), 1),
        "ellipsis_use":   text.count('...') / max(len(words), 1),
    }

def style_match_score(new_feats: dict, history_feats: list) -> int:
    if not history_feats:
        return 50
    keys     = new_feats.keys()
    averages = {k: sum(f[k] for f in history_feats) / len(history_feats) for k in keys}
    diffs    = [min(abs(new_feats[k] - averages[k]) / max(averages[k], 0.001), 1.0) for k in keys]
    return int((1 - sum(diffs) / len(diffs)) * 100)

def compute_user_threshold(history: list, centroid) -> int:
    if len(history) < 10:
        return 45
    sample = history[-50:]
    scores = [
        util.cos_sim(sentence_model.encode(m, convert_to_tensor=True), centroid).item()
        for m in sample
    ]
    mean_s = sum(scores) / len(scores)
    std_s  = (sum((s - mean_s) ** 2 for s in scores) / len(scores)) ** 0.5
    return max(25, min(int((mean_s - 2 * std_s) * 100), 70))

# ── 5. CORE SCORER ────────────────────────────────────────────
def score_single_message(text: str, centroid, style_history: list) -> dict:
    msg_vec        = sentence_model.encode(text, convert_to_tensor=True)
    semantic_score = int(max(0, util.cos_sim(msg_vec, centroid).item()) * 100)
    style_score    = style_match_score(get_stylometric_features(text), style_history)
    final_score    = int(semantic_score * 0.35 + style_score * 0.65)
    return {"semantic": semantic_score, "style": style_score, "final": final_score}

# ── 6. IMAGE HELPERS ──────────────────────────────────────────
def generate_ela_heatmap(image_bytes: bytes):
    nparr = np.frombuffer(image_bytes, np.uint8)
    img   = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    if img is None:
        return None
    def compress_diff(q):
        _, enc = cv2.imencode('.jpg', img, [int(cv2.IMWRITE_JPEG_QUALITY), q])
        comp   = cv2.imdecode(enc, cv2.IMREAD_COLOR)
        return np.clip(cv2.absdiff(img, comp).astype(np.float32) * (300 // q), 0, 255)
    combined = np.maximum(compress_diff(75), compress_diff(92)).astype(np.uint8)
    heatmap  = cv2.applyColorMap(cv2.cvtColor(combined, cv2.COLOR_BGR2GRAY), cv2.COLORMAP_JET)
    _, buf   = cv2.imencode('.png', heatmap)
    return f"data:image/png;base64,{base64.b64encode(buf).decode()}"

@app.get("/", response_class=HTMLResponse)
async def dashboard():
    db            = get_db()
    total         = len(db)
    total_msgs    = sum(len(v.get("history", [])) for v in db.values())
    avg_threshold = int(sum(v.get("threshold", 45) for v in db.values()) / max(total, 1))

    rows = "".join([
        f"""<tr>
            <td>{v['name']}</td>
            <td><span class="badge">{v['platform']}</span></td>
            <td>{len(v.get('history', []))}</td>
            <td>{v.get('threshold', 45)}%</td>
            <td class="ok">● Enrolled</td>
        </tr>"""
        for k, v in db.items()
    ])

    return f"""<!DOCTYPE html>
<html><head><title>TrustEngine NDE v4.7</title><meta charset="utf-8">
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ background: #080d14; color: #e2e8f0; font-family: system-ui, sans-serif; padding: 40px; }}
  h1 {{ font-size: 26px; font-weight: 800; color: #60a5fa; margin-bottom: 4px; }}
  .sub {{ color: #64748b; font-size: 13px; margin-bottom: 32px; }}
  .dot {{ display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: #22c55e; margin-right: 8px; }}
  .cards {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 32px; }}
  .card {{ background: #0f172a; border: 1px solid #1e293b; border-radius: 14px; padding: 24px; }}
  .card-val {{ font-size: 36px; font-weight: 800; color: #3b82f6; }}
  .card-label {{ font-size: 12px; color: #64748b; margin-top: 6px; text-transform: uppercase; }}
  table {{ width: 100%; border-collapse: collapse; background: #0f172a; border-radius: 14px; overflow: hidden; border: 1px solid #1e293b; }}
  th {{ background: #1e293b; padding: 12px 16px; text-align: left; font-size: 11px; color: #94a3b8; text-transform: uppercase; }}
  td {{ padding: 14px 16px; font-size: 14px; border-bottom: 1px solid #1e293b; color: #cbd5e1; }}
  .badge {{ background: #1d4ed8; color: #bfdbfe; font-size: 10px; padding: 3px 8px; border-radius: 6px; text-transform: uppercase; }}
  .ok {{ color: #22c55e; font-size: 13px; }}
</style></head>
<body>
  <h1>🛡️ TrustEngine NDE <span style="font-size:14px;color:#334155;font-weight:400;">v4.7</span></h1>
  <div class="sub"><span class="dot"></span>Backend online · {datetime.now().strftime("%d %b %Y, %H:%M")}</div>
  <div class="cards">
    <div class="card"><div class="card-val">{total}</div><div class="card-label">Enrolled Identities</div></div>
    <div class="card"><div class="card-val">{total_msgs}</div><div class="card-label">Training Messages</div></div>
    <div class="card"><div class="card-val">{avg_threshold}%</div><div class="card-label">Avg Trust Threshold</div></div>
  </div>
  <table>
    <tr><th>Name</th><th>Platform</th><th>Messages</th><th>Threshold</th><th>Status</th></tr>
    {rows or '<tr><td colspan="5" style="text-align:center;color:#475569;padding:30px;">No identities enrolled yet.</td></tr>'}
  </table>
</body></html>"""
# ── 8. IDENTITY ROUTES ────────────────────────────────────────
@app.post("/enroll/contact")
async def enroll_contact(payload: dict):
    chat_id  = str(payload.get("chatID") or payload.get("username"))
    name     = payload.get("name", "Unknown")
    platform = payload.get("platform", "unknown")
    new_messages = payload.get("messages", [])

    db = get_db()
    if chat_id not in db:
        db[chat_id] = {
            "name": name, "platform": platform,
            "history": [], "style_history": [],
            "threshold": 45, "risk": "Verified"
        }

    def to_text(m):
        return m["text"] if isinstance(m, dict) else str(m)

    incoming = [to_text(m) for m in new_messages]
    db[chat_id]["history"] = list(set(db[chat_id]["history"] + incoming))
    db[chat_id].setdefault("style_history", []).extend(
        [get_stylometric_features(m) for m in incoming]
    )

    if len(db[chat_id]["history"]) >= 10:
        history   = db[chat_id]["history"]
        hist_vecs = sentence_model.encode(history, convert_to_tensor=True)
        centroid  = torch.mean(hist_vecs, dim=0)
        db[chat_id]["threshold"] = compute_user_threshold(history, centroid)

    db[chat_id]["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    save_db(db)
    print(f"📈 Enrolled: {name} | {len(db[chat_id]['history'])} msgs | threshold {db[chat_id]['threshold']}%")
    return {"status": "success", "contact": name}

@app.get("/contacts")
async def list_contacts():
    return get_db()

@app.delete("/contact/{chat_id}")
async def delete_contact(chat_id: str):
    db = get_db()
    if chat_id not in db:
        return JSONResponse(status_code=404, content={"status": "not_found"})
    name = db[chat_id].get("name", chat_id)
    del db[chat_id]
    save_db(db)
    print(f"🗑️  Deleted: {name}")
    return {"status": "deleted", "contact": name}

# ── 9. TEXT VERIFY with conversation context ──────────────────
@app.post("/verify/text")
async def verify_text(payload: dict):
    try:
        text             = payload.get("text", "")
        chat_id          = str(payload.get("chatID", ""))
        context_messages = payload.get("context", [])  # last N msgs from current convo
        db               = get_db()

        if chat_id not in db or not db[chat_id].get("history"):
            return {
                "verdict": "⚠️ NO DATA", "badge_color": "gray",
                "semantic_score": 0, "style_score": 0,
                "final_score": 0, "confidence": 0,
                "threshold": 45, "context_used": 0
            }

        history       = db[chat_id]["history"]
        style_history = db[chat_id].get("style_history", [])
        threshold     = db[chat_id].get("threshold", 45)

        hist_vecs = sentence_model.encode(history, convert_to_tensor=True)
        centroid  = torch.mean(hist_vecs, dim=0)

        # Score the target message
        target = score_single_message(text, centroid, style_history)

        # ── CONVERSATION CONTEXT ──────────────────────────────────────────────
        # Score each of the last 5 context messages with exponential decay weights
        # Most recent context message counts most, older messages fade
        context_score = None
        if context_messages:
            recent     = list(reversed(context_messages[-5:]))  # newest first
            weights    = [0.5 ** i for i in range(len(recent))] # 1, 0.5, 0.25, 0.125, 0.0625
            weight_sum = sum(weights)

            weighted_final = 0
            for msg, w in zip(recent, weights):
                s = score_single_message(msg, centroid, style_history)
                weighted_final += s["final"] * w

            context_score = int(weighted_final / weight_sum)

        # Blend: target 70% + conversation context 30%
        if context_score is not None:
            final_score = int(target["final"] * 0.70 + context_score * 0.30)
        else:
            final_score = target["final"]

        verdict = "✅ AUTHENTIC" if final_score >= threshold else "🤨 IMPOSTER"
        color   = "green"       if final_score >= threshold else "yellow"

        print(
            f"  ChatID    : {chat_id}\n"
            f"  Semantic  : {target['semantic']}%  |  Style: {target['style']}%\n"
            f"  Target    : {target['final']}%  |  Context: {context_score}%\n"
            f"  Final     : {final_score}%  (threshold: {threshold}%)\n"
            f"  Verdict   : {verdict}"
        )

        return {
            "verdict":        verdict,
            "badge_color":    color,
            "semantic_score": target["semantic"],
            "style_score":    target["style"],
            "final_score":    final_score,
            "confidence":     final_score,
            "threshold":      threshold,
            "context_used":   len(context_messages)
        }

    except Exception as e:
        print(f"❌ ERROR: {e}")
        return {
            "verdict": "ERROR", "badge_color": "red",
            "semantic_score": 0, "style_score": 0,
            "final_score": 0, "confidence": 0, "threshold": 45
        }

# ── 10. IMAGE VERIFY ─────────────────────────────────────────
@app.post("/verify/image")
async def verify_image(file: UploadFile = File(...), photo_type: str = Form("auto")):
    image_bytes = await file.read()

    fft_result     = analyze_fft_grid(image_bytes)
    liveness_score = 0

    if photo_type in ("face", "auto"):
        liveness       = analyze_liveness(image_bytes)
        liveness_score = liveness.confidence

    scores = {"FFT Scanner": fft_result.grid_score}
    if liveness_score > 0:
        scores["Liveness"] = liveness_score

    consensus: ConsensusResult = resolve_consensus(scores, pipeline_category="generic")

    return {
        "verdict":     consensus.verdict.upper(),
        "final_score": round(consensus.final_score, 1),
        "badge_color": "red" if consensus.final_score > 70 else "green",
        "heatmap":     generate_ela_heatmap(image_bytes),
        "details":     [{"name": k, "score": v} for k, v in scores.items()]
    }